%%FRICTION COEFFICIENT FOR CONTINUOUS APPROXIMATION TO LOCKING STATIC FRICTION
% Coefficient of friction versus relative velocity (slip)

% Copyright 2008-2009 The MathWorks, Inc.

% Need to have VTH, MUK, MUS predefined in workspace.
% Load <continuousPiston> model first to populate workspace.
% Set recursion limit
set(0,'RecursionLimit',150)

% NUMBER OF POINTS ON CURVE
num_fs_pts = 101;

% CURVE LIMITS
v_lowlim = -3*VTH;
v_upplim =  3*VTH;

% GENERATE X-AXIS POINTS (velocity)
v_pts = linspace(v_lowlim, v_upplim, num_fs_pts);

% DETERMINE Y-AXIS POINTS (coefficient of friction)
for i=1:num_fs_pts
    if(v_pts(i)<(-1.5*VTH))
        mu_pts(i) = -MUK;
    elseif(v_pts(i)>=-1.5*VTH && v_pts(i)<-VTH)
        mu_pts(i) = -(MUK-MUS)/(0.5*VTH)*(-1.5*VTH-v_pts(i))-MUK;
    elseif(v_pts(i)>=-VTH && v_pts(i)<VTH)
        mu_pts(i) = -(MUS)/VTH*(-VTH-v_pts(i))-MUS;
    elseif(v_pts(i)>=VTH && v_pts(i)<1.5*VTH)
        mu_pts(i) = (MUK-MUS)/(0.5*VTH)*(v_pts(i)-1.5*VTH)+MUK;
    elseif(v_pts(i)>=(1.5*VTH))
        mu_pts(i) = MUK;
    end
end

plot(v_pts,mu_pts);
set(gca,'XLim',[-3*VTH,3*VTH]);
xlabel('Relative velocity (slip) (m/s)')
ylabel('Coefficient of friction')